Histogram Filter
================
.. figure:: ../../pyreverse_output/HF.png
   :scale: 75 %
   :align: center
   :alt: Histogram Filter Class Diagram

.. autoclass:: HF.HF

.. autoclass:: Histogram.Histogram2D

