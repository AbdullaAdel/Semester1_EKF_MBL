Robot Localization
------------------
.. figure:: ../../pyreverse_output/Localization.png
   :scale: 75 %
   :align: center
   :alt: Localization Class Diagram

.. autoclass:: Localization.Localization
