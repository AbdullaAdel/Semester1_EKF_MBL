Feature based EKF Simultaneous Localization And Mapping
-------------------------------------------------------


FEKFSLAM Feature
----------------
.. figure:: ../../pyreverse_output/FEKFSLAMFeature.png
   :scale: 75 %
   :align: center
   :alt: FEKFSLAMFeature Diagram

.. autoclass:: FEKFSLAMFeature.FEKFSLAMFeature

FEKF SLAM Localization
----------------------
.. figure:: ../../pyreverse_output/FEKFSLAM.png
   :scale: 75 %
   :align: center
   :alt: FEKFSLAM Diagram

.. autoclass:: FEKFSLAM.FEKFSLAM