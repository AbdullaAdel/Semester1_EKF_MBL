Filters
=======

Histogram Filter
----------------
.. toctree::
   :maxdepth: 2

   HF

Particle Filter
---------------
.. toctree::
   :maxdepth: 2

   PF

Gaussian Filter
---------------
.. toctree::
   :maxdepth: 2

   GF

Kalman Filter
.............
.. toctree::
   :maxdepth: 2

   KF

Extended Kalman Filter
......................
.. toctree::
   :maxdepth: 2

   EKF